import logo from './logo.svg';
import './App.css';
import './page/login.js'
import Login from './page/login.js';


function App() {
  return (
    <main className='App'>
      <Login/>
    </main>
  );
}

export default App;
